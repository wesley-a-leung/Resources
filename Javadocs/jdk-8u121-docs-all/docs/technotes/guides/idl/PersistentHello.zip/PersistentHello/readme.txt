To run this client-server application on your development machine: 

1. Change to the directory that contains the file PersistentHello.idl.

2. Run the IDL-to-Java compiler, idlj, on the IDL file to
create stubs and skeletons.  This step assumes that you have included
the path to the java/bin directory in your path. 

   idlj  -fall -td . -verbose  PersistentHello.idl

3. Compile the .java files, including the stubs and skeletons
(which are in the directory Persistent).  This step assumes the java/bin  
directory is included in your path.

   javac *.java Persistent/*.java

4. Start orbd as follows: 

   orbd -ORBInitialPort 1050 -serverPollingTime 200 

5. Start the Hello server:

   a. Start the servertool from the command line as follows:

       servertool -ORBInitialPort 1050 

       Make sure the name server (orbd) port is the same as in the
       previous step, for example, -ORBInitialPort  1050. The 
       servertool must be started on the same port as the name server.

   b. Register the PersistentServer from the servertool prompt, 
   as shown below.  Type the information in one long string without returns.
   
       servertool  > register -server PersistentServer -applicationName s1 
                -classpath <em>path_to_server_class_files</em> 

6. Run the client application:

      java -classpath . PersistentClient 
  
   The terminal window or DOS prompt displays the following messages:


Calling Persistent Server..
Message From Persistent Server: Hello From Persistent Server...
Shutting down Persistent Server..
Calling Persistent Server..
Message From Persistent Server: Hello From Persistent Server...
Shutting down Persistent Server..


