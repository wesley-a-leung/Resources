
More detailed instructions on how to compile/run this example can be
found in the sample top-level README file.

The following urls have more information about RMI and the
HelloWorld example:

        http://java.sun.com/j2se/1.5.0/docs/guide/rmi/index.html
	http://java.sun.com/docs/books/tutorial/rmi/index.html

